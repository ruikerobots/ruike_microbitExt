# mbit

Extension for Yahboom mbit

## License

MIT

## Supported targets

* for PXT/microbit
(The metadata above is needed for package search.)
